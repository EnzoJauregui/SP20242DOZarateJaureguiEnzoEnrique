class Vehiculo{
    constructor (modelo, anoFabricacion,velMax, id){
        this.id = id;
        this.modelo = modelo;
        this.anoFabricacion = anoFabricacion;
        this.velMax = velMax;
    }
    toJson() {
        return JSON.stringify({
            modelo: this.modelo,
            anoFabricacion: this.anoFabricacion,
            velMax: this.velMax
        });
    }

    toString() {
        return `ID: ${this.id}, Modelo: ${this.modelo}, Año de fabricacion: ${this.anoFabricacion}, Velocidad maxima: ${this.velMax}`;
    }
}

class Auto extends Vehiculo{
    constructor(modelo, anoFabricacion,velMax,cantidadPuertas, asientos, id){
        super(modelo, anoFabricacion,velMax, id)
        this.cantidadPuertas = cantidadPuertas;
        this.asientos = asientos;
    }

    toJson() {
        let vehiculoJson = JSON.parse(super.toJson()); 
        vehiculoJson.cantidadPuertas = this.cantidadPuertas;
        vehiculoJson.asientos = this.asientos;
        return JSON.stringify(vehiculoJson); 
    }

    toString() {
        return `${super.toString()}, Cantidad de puertas: ${this.cantidadPuertas}, Asientos: ${this.asientos}`;
    }
}

class Camion extends Vehiculo{
    constructor(modelo, anoFabricacion,velMax, carga, autonomia, id){
        super(modelo, anoFabricacion,velMax, id)
        this.carga = carga;
        this.autonomia = autonomia;
    }
    toString() {
        return `${super.toString()}, Compras: ${this.carga}, Telefono: ${this.autonomia}`;
    }
    toJson() {
        let vehiculoJson = JSON.parse(super.toJson()); 
        vehiculoJson.carga = this.carga;
        vehiculoJson.autonomia = this.autonomia;
        return JSON.stringify(vehiculoJson); 
    }
}
const URL_OBJETOS = 'https://examenesutn.vercel.app/api/VehiculoAutoCamion';
let objetos = [];


function getXmlObjetos(){
    mostrarOcularSpinner("flex");
    let xml = new XMLHttpRequest();
    
    xml.onreadystatechange = function(){
        if(xml.readyState==4){
            if(xml.status ==200){
                mostrarOcularSpinner("none");
                objetos = parsearObjetos(JSON.parse(xml.responseText));                
                console.log(objetos);
                mostrarDatos(objetos);
            }
            else{
                console.error(`Error ${xml.status}: ${xml.statusText}`);
            }
        }
    }
    xml.open('GET', URL_OBJETOS);
    try{
        xml.send();
    }catch(e){
        console.error(e);
    }
}

async function AltaPromiseObjeto(nuevoObjeto) {
    mostrarOcularSpinner("flex");

    try {
        let requestBody = nuevoObjeto.toJson();

        
        let response = await fetch(URL_OBJETOS, {
            method: 'POST',
            headers: {
                "Content-Type": "application/json"
            },
            body: requestBody
        });

        if (response.ok && response.status === 200) {
            let data = await response.json();
            nuevoObjeto.id = data.id;
            objetos.push(nuevoObjeto);
            mostrarDatos(objetos);
            flagHabilitar = true;
            return objetos; 
        } else {
            throw new Error(`Error ${response.status}: ${response.statusText}`);
        }

    } catch (error) {
        throw new Error(`Error en la operación POST: ${error.message}`);
    } finally {
        mostrarOcularSpinner("none");
    }
}


function modificarPromiseObjeto(objeto, i){
    mostrarOcularSpinner("flex");
    let requestBody = JSON.stringify(objeto);

    new Promise((exito, fracaso) => {
        fetch(URL_OBJETOS, {
            method: 'PUT',
            headers: { "Content-Type": "application/json" },
            body: requestBody
        })
        .then(res => {
            if (res.ok && res.status === 200) {
                objetos[i] = objeto;
                exito(objetos);
            } 
            else if (res.status === 500) { 
                throw new Error("No permitido");
            }
            else if(res.status === 400){
                throw new Error("error en el body")
            } 
            else {
                throw new Error(`Error ${res.status}: ${text}`);
            }
        })
        .catch(error => fracaso(`Error en la solicitud: ${error}`));
    })
    .then(() => {
        mostrarDatos(objetos); 
        ocultarForm("block", "none"); 
    })
    .catch(error => console.error(error))
    .finally(() => mostrarOcularSpinner("none"));
}

async function eliminarFetchElemento(i){
    mostrarOcularSpinner("flex");
    let requestBody = JSON.stringify({id: objetos[i].id});
    console.log(requestBody);

    try{
        let response = await fetch(URL_OBJETOS, {
            method: 'DELETE',
            headers: {
                "Content-Type": "application/json"
            },
            body: requestBody
        });

        mostrarOcularSpinner("none");

        if(response.ok && response.status === 200){
            objetos.splice(i, 1);
            mostrarDatos(objetos);
        } 
        else if(response.status === 500){
            throw new Error("No valido");
        }
        else if(response.status === 400){
            throw new Error("error en el body")
        }
        else{
            throw new Error(`Error ${response.status}: ${response.statusText}`);
        }
    } catch (error) {
        console.error("Error en la operación:", error);
    } finally {
        mostrarOcularSpinner("none");
        ocultarForm("block", "none");
    }
}

function mostrarOcularSpinner(value)
{
    document.getElementById("spinner").style.display = value;
}

function parsearObjetos(arrayObjetos)
{
    return arrayObjetos.map((item)=>{
        if(item.carga === undefined){
            return new Auto(item.modelo, item.anoFabricacion, item.velMax, item.cantidadPuertas, item.asientos,item.id);
        }
        else{
            return new Camion(item.modelo, item.anoFabricacion, item.velMax, item.carga, item.autonomia, item.id);
        }
    });
}  

function mostrarDatos(datos){
    let tbody = document.querySelector("#tablaObjetos tbody");
    tbody.innerHTML='';
    let i=0;
    datos.forEach((item)=>{
        const row = document.createElement("tr");
        row.setAttribute("id", `objeto${i}`);
        
        row.innerHTML = `
        <td class="id">${item.id}</td>
        <td class="modelo">${item.modelo}</td>
        <td class="anoFabricacion">${item.anoFabricacion}</td>
        <td class="velMax">${item.velMax}</td>
        <td class="cantidadPuertas">${item.cantidadPuertas !== undefined ? item.cantidadPuertas : "N/A"}</td>
        <td class="asientos">${item.asientos !== undefined ? item.asientos : "N/A"}</td>
        <td class="carga">${item.asientos === undefined ? item.carga : "N/A"}</td>
        <td class="autonomia">${item.asientos === undefined ? item.autonomia : "N/A"}</td>
        <td><input type="button" name="modificar" data-content="${i}" value='Modificar'></td>
        <td><input type="button" name="eliminar" data-content="${i}" value='Eliminar'></td>
        `
        tbody.appendChild(row);
        i++;
    })
    limpiarFormulario();
    agregarEventoClick("modificar");
    agregarEventoClick("eliminar");
}

function agregarEventoClick(nameBoton) {
    let botones = document.getElementsByName(nameBoton);
    for (let boton of botones) {
        boton.onclick = null;
        boton.onclick = ()=>{
            let i = boton.getAttribute("data-content");
            
            if(nameBoton == "modificar"){
                
                modificarElemento(i, "Modificar");
            }
            else if(nameBoton == "eliminar"){
                eliminarElemento(i, "Eliminar");
            }
        }
    }
}

function botonAceptar(modoActual, tipoObjeto, i){
    let buttonAceptar = document.getElementById("btnAceptar");
    let objeto;
    console.log(modoActual)
    buttonAceptar.onclick = null;
    buttonAceptar.onclick = ()=>{
        let modelo = document.getElementById("txtModelo").value;
        let anoFabricacion = parseInt(document.getElementById("txtAnoFabricacion").value);
        let velMax = parseInt(document.getElementById("txtVelMax").value, 10);
        console.log(tipoObjeto);
        if (modoActual === "Modificar") {
            if(objetos[i] instanceof Camion){
                let carga = parseInt(document.getElementById("txtCarga").value, 10);
                let autonomia = parseInt(document.getElementById("txtAutonomia").value, 10);
                
                if(!validarDatosVehiculo(modelo, anoFabricacion, velMax) || !validarDatosHijos(carga, autonomia, 0)){
                    alert("Por favor, completa todos los campos correctamente.");
                    return;
                }
                objeto = new Camion(modelo, anoFabricacion, velMax, carga, autonomia, objetos[i].id);
            }
            else if(objetos[i] instanceof Auto){
                let cantPuertas = parseInt(document.getElementById("txtCantidadPuertas").value, 10);
                let asientos = parseInt(document.getElementById("txtAsientos").value, 10);
                
                if(!validarDatosVehiculo(modelo, anoFabricacion, velMax) || !validarDatosHijos(cantPuertas, asientos,2)){
                    alert("Por favor, completa todos los campos correctamente.");
                    return;
                }
                objeto = new Auto(modelo, anoFabricacion, velMax, asientos, cantPuertas, objetos[i].id);
            }
            modificarPromiseObjeto(objeto, i);
        } 
        else if (modoActual === "Alta"){
            if(tipoObjeto == "auto"){
                let cantidadPuertas = parseInt(document.getElementById("txtCantidadPuertas").value, 10);
                let asientos = parseInt(document.getElementById("txtAsientos").value, 10);
                
                if(!validarDatosVehiculo(modelo, anoFabricacion, velMax) || !validarDatosHijos(cantidadPuertas, asientos,0)){
                    alert("Por favor, completa todos los campos correctamente.");
                    return;
                }
                console.log( cantidadPuertas);
                objeto = new Auto(modelo, anoFabricacion, velMax, cantidadPuertas, asientos, 0);
            }
            else if(tipoObjeto == "camion"){
                let carga = parseInt(document.getElementById("txtCarga").value, 10);
                let autonomia = parseInt(document.getElementById("txtAutonomia").value, 10);
                
                if(!validarDatosVehiculo(modelo, anoFabricacion, velMax) || !validarDatosHijos(carga, autonomia,2)){
                    alert("Por favor, completa todos los campos correctamente.");
                    return;
                }
                objeto = new Camion(modelo, anoFabricacion, velMax, carga, autonomia, 0);
            }
            
            ocultarForm("block", "none");
            AltaPromiseObjeto(objeto);

        }
        else if(modoActual == "Eliminar"){
            eliminarFetchElemento(i);
        }
    }
}

function agregarElemeto(){
    let btnAgregar = document.getElementById("btnAgregar");
    let modoActual ="Alta";
    btnAgregar.addEventListener("click", () => {
        document.getElementById("sectionId").style.display ="none";
        document.getElementById("sectionTipo").style.display = "block";
        document.getElementById("hAbm").textContent = modoActual;
        ocultarForm("none", "block");    
        modoActual = "Alta";
        
        let tipoObjeto = "auto";
        let visCamion = "block";
        let visAuto = "none";
        let selectTipo = document.getElementById("tipoObjeto");

        selectTipo.addEventListener("change", () => {
            if(selectTipo.value == "camion"){
                visCamion = "block";
                visAuto = "none"; 
                tipoObjeto = "camion";
            }
            else if(selectTipo.value == "auto"){
                visCamion = "none";
                visAuto = "block";
                tipoObjeto = "auto";
            }
            ocultarDatosAbm("abmCamion", visCamion);
            ocultarDatosAbm("abmAuto", visAuto);
            console.log(modoActual)
        });
        botonAceptar(modoActual, tipoObjeto,0);
        cancelar();
    });
}

function modificarElemento(i){
    limpiarFormulario();
    let modoActual = "Modificar";
    document.getElementById("hAbm").innerText = modoActual;
    document.getElementById("sectionTipo").style.display = "none";
    ocultarForm("none", "block")
    llenarCampos(i);
    botonAceptar(modoActual,'',i);
    cancelar();
}

function llenarCampos(i){
    document.getElementById("sectionId").style.display = "block";
    let txtId = document.getElementById("txtId");
    txtId.value = objetos[i].id
    txtId.readOnly = true;
    document.getElementById("txtModelo").value = objetos[i].modelo;
    document.getElementById("txtAnoFabricacion").value = objetos[i].anoFabricacion;
    document.getElementById("txtVelMax").value = objetos[i].velMax;

    if(objetos[i] instanceof Auto){
        ocultarDatosAbm("abmAuto", "block");
        ocultarDatosAbm("abmCamion", "none");
        document.getElementById("txtCantidadPuertas").value = objetos[i].cantidadPuertas;
        document.getElementById("txtAsientos").value = objetos[i].asientos;
    }
    else if(objetos[i] instanceof Camion){
        ocultarDatosAbm("abmAuto", "none");
        ocultarDatosAbm("abmCamion", "block");
        document.getElementById("txtCarga").value = objetos[i].carga;
        document.getElementById("txtAutonomia").value = objetos[i].autonomia;
    }
}

function eliminarElemento(i, modo){
    limpiarFormulario();
    let modoActual = "Eliminar";
    document.getElementById("hAbm").innerText = modoActual;
    document.getElementById("sectionTipo").style.display = "none";
    ocultarForm("none", "block")
    llenarCampos(i);
    botonAceptar(modo,"",i);
    cancelar();
}
function cancelar(){
    document.getElementById("btnCancelar").onclick = ()=>{
        ocultarForm("block", "none");
        limpiarFormulario();
    }
}

function validarDatosVehiculo(modelo, anoFabricacion, velMax){
    if(!modelo || anoFabricacion<1985 || velMax <=0){
        return false;
    }
    return true;
}

function validarDatosHijos(atributo1, atributo2, min){
    if(atributo1 <= min || atributo2 <= min){
        return false;
    }
    return true;
}

function ocultarForm(visivilidadTablas, visivilidadAbm){
    document.getElementById("formObjetos").style.display = visivilidadTablas;
    document.getElementById("abm").style.display = visivilidadAbm;
}

function ocultarDatosAbm(classname, visibilidad) {
    let groupClass = document.getElementsByClassName(classname);
    for(let item of groupClass){
        item.style.display = visibilidad;
    }
}

function limpiarFormulario() {
    document.getElementById("txtId").value = '';
    document.getElementById("txtModelo").value = '';
    document.getElementById("txtAnoFabricacion").value = '';
    document.getElementById("txtVelMax").value = '';
    document.getElementById("txtCantidadPuertas").value = '';
    document.getElementById("txtAsientos").value = '';
    document.getElementById("txtCarga").value = '';
    document.getElementById("txtAutonomia").value = '';
}
function main(){
    agregarElemeto();
    getXmlObjetos();
}
main();